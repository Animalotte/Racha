﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Racha_APIs.data;
using Racha_APIs.models;
using System.Linq;

namespace Racha_APIs.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CartaoController : ControllerBase
    {
        private readonly RachaDBContext _context;

        public CartaoController(RachaDBContext context)
        {
            _context = context;
        }

        [HttpPost("criar")]
        public IActionResult CriarCartao([FromBody] CriarCartaoDto dto)
        {
            if (dto == null || string.IsNullOrEmpty(dto.Nome) || dto.Valor <= 0 || dto.CriadorId <= 0)
            {
                return BadRequest(new { message = "Dados inválidos para criação do cartão" });
            }

            var criador = _context.Usuarios.Find(dto.CriadorId);
            if (criador == null)
            {
                return NotFound(new { message = "Criador não encontrado" });
            }

            var cartao = new Cartao
            {
                Nome = dto.Nome,
                Valor = dto.Valor,
                Descricao = dto.Descricao ?? "",
                CriadorId = dto.CriadorId,
                CriadorNome = criador.NomeCompleto,
                DivisaoTipo = dto.DivisaoTipo ?? "igualitaria",
                Status = "pendente",
                DataCriacao = DateTime.UtcNow,
                PagamentosRealizados = 0
            };

            var validConvidados = new List<Usuario>();
            var erros = new List<string>();

            foreach (var codigo in dto.CodigosConvidados.Distinct())
            {
                var convidado = _context.Usuarios.FirstOrDefault(u => u.CodigoUnico == codigo);
                if (convidado == null)
                {
                    erros.Add($"Código {codigo} inválido");
                    continue;
                }
                if (convidado.Id == criador.Id)
                {
                    erros.Add($"Não pode convidar a si mesmo: {codigo}");
                    continue;
                }
                if (validConvidados.Any(v => v.Id == convidado.Id))
                {
                    erros.Add($"Usuário duplicado: {codigo}");
                    continue;
                }

                validConvidados.Add(convidado);
            }

            if (erros.Any())
            {
                return BadRequest(new { message = "Erros nos convites", erros });
            }

            cartao.NumeroParticipantes = validConvidados.Count + 1;

            _context.Cartoes.Add(cartao);
            _context.SaveChanges();

            var participanteCriador = new Participante
            {
                CartaoId = cartao.Id,
                UsuarioId = criador.Id,
                Nome = criador.NomeCompleto,
                Email = criador.Email,
                Status = "aceito",
                ValorPago = 0,
                PagamentoRealizado = false
            };
            _context.Participantes.Add(participanteCriador);

            var convidadosAdicionados = new List<string>();
            foreach (var convidado in validConvidados)
            {
                var participante = new Participante
                {
                    CartaoId = cartao.Id,
                    UsuarioId = convidado.Id,
                    Nome = convidado.NomeCompleto,
                    Email = convidado.Email,
                    Status = "pendente",
                    ValorPago = 0,
                    PagamentoRealizado = false
                };
                _context.Participantes.Add(participante);
                convidadosAdicionados.Add(convidado.CodigoUnico);
            }
            _context.SaveChanges();

            return Ok(new
            {
                sucesso = true,
                cartaoId = cartao.Id,
                mensagem = "Cartão criado",
                convidadosAdicionados
            });
        }

        [HttpGet("convites/{usuarioId}")]
        public IActionResult GetConvitesPendente(int usuarioId)
        {
            var convites = _context.Participantes
                .Include(p => p.Cartao)
                .Where(p => p.UsuarioId == usuarioId && p.Status == "pendente")
                .Select(p => new
                {
                    id = p.CartaoId,
                    cartaoNome = p.Cartao.Nome,
                    remetenteId = p.Cartao.CriadorId,
                    remetenteNome = p.Cartao.CriadorNome,
                    valor = p.Cartao.Valor,
                    numeroParticipantes = p.Cartao.NumeroParticipantes,
                    dataEnvio = p.Cartao.DataCriacao.ToString("dd/MM/yyyy HH:mm"),
                    status = p.Status 
                })
                .ToList();

            return Ok(convites);
        }

        [HttpPost("{id}/aceitar")]
        public IActionResult AceitarConvite(int id, [FromBody] AceitarDto dto)
        {
            if (dto?.UsuarioId <= 0) return BadRequest(new { message = "Dados inválidos" });

            var participante = _context.Participantes
                .FirstOrDefault(p => p.CartaoId == id && p.UsuarioId == dto.UsuarioId);

            if (participante == null || participante.Status != "pendente")
            {
                return NotFound(new { message = "Convite não encontrado ou já processado" });
            }

            participante.Status = "aceito";
            _context.SaveChanges();

            var cartao = _context.Cartoes.Find(id);
            if (cartao != null)
            {
                var aceitos = _context.Participantes.Count(p => p.CartaoId == id && p.Status == "aceito");
                if (aceitos == cartao.NumeroParticipantes)
                {
                    cartao.Status = "ativo";
                    _context.SaveChanges();
                }
            }

            return Ok(new { message = "Convite aceito com sucesso" });
        }

        [HttpPost("{id}/rejeitar")]
        public IActionResult RejeitarConvite(int id, [FromBody] RejeitarDto dto)
        {
            if (dto?.UsuarioId <= 0) return BadRequest(new { message = "Dados inválidos" });

            var participante = _context.Participantes
                .FirstOrDefault(p => p.CartaoId == id && p.UsuarioId == dto.UsuarioId);

            if (participante == null || participante.Status != "pendente")
            {
                return NotFound(new { message = "Convite não encontrado ou já processado" });
            }

            _context.Participantes.Remove(participante);
            _context.SaveChanges();

            return Ok(new { message = "Convite rejeitado com sucesso" });
        }

        [HttpPost("{id}/pagar")]
        public IActionResult Pagar(int id, [FromBody] PagarDto dto)
        {
            if (dto?.ParticipanteId <= 0) return BadRequest(new { message = "Dados inválidos" });

            var participante = _context.Participantes
                .FirstOrDefault(p => p.CartaoId == id && p.UsuarioId == dto.ParticipanteId);

            if (participante == null || participante.Status != "aceito" || participante.PagamentoRealizado)
            {
                return BadRequest(new { message = "Pagamento inválido" });
            }

            var cartao = _context.Cartoes.Find(id);
            if (cartao == null || cartao.Status != "ativo") return BadRequest(new { message = "Cartão não ativo" });

            var usuario = _context.Usuarios.Find(dto.ParticipanteId);
            if (usuario == null) return NotFound(new { message = "Usuário não encontrado" });

            var valorPorPessoa = cartao.Valor / cartao.NumeroParticipantes;
            if (usuario.Creditos < valorPorPessoa) return BadRequest(new { message = "Saldo insuficiente" });

            usuario.Creditos -= valorPorPessoa;
            participante.ValorPago = valorPorPessoa;
            participante.PagamentoRealizado = true;
            cartao.PagamentosRealizados++;

            if (cartao.PagamentosRealizados == cartao.NumeroParticipantes)
            {
                cartao.Status = "validado";
                cartao.DadosCartao = new DadosCartao(cartao.Nome);
            }

            _context.SaveChanges();

            var transacao = new Transacao
            {
                UsuarioId = dto.ParticipanteId,
                Tipo = "cartao_payment",
                Amount = valorPorPessoa,
                Date = DateTime.UtcNow,
                Description = $"Pagamento para cartão {cartao.Nome}",
                CartaoId = id,
                CartaoName = cartao.Nome
            };
            _context.Transacoes.Add(transacao);
            _context.SaveChanges();

            return Ok(new { message = "Pagamento realizado com sucesso" });
        }

        [HttpGet("{id}")]
        public IActionResult GetCartao(int id)
        {
            var cartao = _context.Cartoes
                .Include(c => c.Participantes)
                .Include(c => c.DadosCartao)
                .FirstOrDefault(c => c.Id == id);

            if (cartao == null) return NotFound(new { message = "Cartão não encontrado" });

            return Ok(new
            {
                id = cartao.Id,
                nome = cartao.Nome,
                valor = cartao.Valor,
                numeroParticipantes = cartao.NumeroParticipantes,
                descricao = cartao.Descricao,
                criadorId = cartao.CriadorId,
                criadorNome = cartao.CriadorNome,
                status = cartao.Status,
                dataCriacao = cartao.DataCriacao.ToString("o"),
                pagamentosRealizados = cartao.PagamentosRealizados,
                participantes = cartao.Participantes.Select(p => new
                {
                    id = p.UsuarioId,
                    nome = p.Nome,
                    email = p.Email,
                    status = p.Status,
                    valorPago = p.ValorPago,
                    pagamentoRealizado = p.PagamentoRealizado
                }),
                dadosCartao = cartao.DadosCartao != null ? new
                {
                    numero = cartao.DadosCartao.Numero,
                    cvv = cartao.DadosCartao.Cvv,
                    validade = cartao.DadosCartao.Validade,
                    nome = cartao.DadosCartao.Nome
                } : null
            });
        }

        [HttpGet("usuario/{usuarioId}")]
        public IActionResult GetCartoesPorUsuario(int usuarioId)
        {
            var cartoes = _context.Cartoes
                .Include(c => c.Participantes)
                .Include(c => c.DadosCartao)
                .Where(c => c.CriadorId == usuarioId ||
                           c.Participantes.Any(p => p.UsuarioId == usuarioId && p.Status == "aceito"))
                .Select(c => new
                {
                    id = c.Id,
                    nome = c.Nome,
                    valor = c.Valor,
                    numeroParticipantes = c.NumeroParticipantes,
                    status = c.Status,
                    dataCriacao = c.DataCriacao.ToString("o"),
                    pagamentosRealizados = c.PagamentosRealizados,
                    participantesAceitos = c.Participantes.Count(p => p.Status == "aceito")
                })
                .ToList();

            return Ok(cartoes);
        }

        [HttpPost("{id}/convidar")]
        public IActionResult Convidar(int id, [FromBody] ConvidarDto dto)
        {
            var cartao = _context.Cartoes.Include(c => c.Participantes).FirstOrDefault(c => c.Id == id);
            if (cartao == null || cartao.Status != "pendente")
                return BadRequest("Cartão inválido ou não pendente");

            var codigo = dto.CodigoUnico;
            var convidado = _context.Usuarios.FirstOrDefault(u => u.CodigoUnico == codigo);
            if (convidado == null)
                return BadRequest($"Código {codigo} inválido");

            if (convidado.Id == cartao.CriadorId)
                return BadRequest($"Não pode convidar a si mesmo: {codigo}");

            if (_context.Participantes.Any(p => p.CartaoId == id && p.UsuarioId == convidado.Id))
                return BadRequest($"Usuário já convidado: {codigo}");

            var participante = new Participante
            {
                CartaoId = cartao.Id,
                UsuarioId = convidado.Id,
                Nome = convidado.NomeCompleto,
                Email = convidado.Email,
                Status = "pendente",
                ValorPago = 0,
                PagamentoRealizado = false
            };
            _context.Participantes.Add(participante);
            cartao.NumeroParticipantes++;
            _context.SaveChanges();

            return Ok(new { mensagem = "Convite enviado" });
        }

        [HttpPut("{id}")]
        public IActionResult UpdateCartao(int id, [FromBody] UpdateCartaoDto dto)
        {
            var cartao = _context.Cartoes.Find(id);
            if (cartao == null)
            {
                return NotFound(new { message = "Cartão não encontrado" });
            }

            if (cartao.Status != "pendente")
            {
                return BadRequest(new { message = "Apenas cartões pendentes podem ser atualizados" });
            }

            if (!string.IsNullOrEmpty(dto.Nome))
            {
                cartao.Nome = dto.Nome;
            }
            if (dto.Valor > 0)
            {
                cartao.Valor = dto.Valor;
            }
            if (!string.IsNullOrEmpty(dto.Descricao))
            {
                cartao.Descricao = dto.Descricao;
            }
            if (!string.IsNullOrEmpty(dto.Status) && new[] { "pendente", "ativo", "validado" }.Contains(dto.Status))
            {
                cartao.Status = dto.Status;
            }

            _context.SaveChanges();
            return Ok(new { message = "Cartão atualizado com sucesso" });
        }
    }

    public class CriarCartaoDto
    {
        public string Nome { get; set; } = string.Empty;
        public decimal Valor { get; set; }
        public string? Descricao { get; set; }
        public int CriadorId { get; set; }
        public string? DivisaoTipo { get; set; }
        public List<string> CodigosConvidados { get; set; } = new();
    }

    public class AceitarDto { public int UsuarioId { get; set; } }
    public class RejeitarDto { public int UsuarioId { get; set; } }
    public class PagarDto { public int ParticipanteId { get; set; } }
    public class ConvidarDto
    {
        public string CodigoUnico { get; set; } = string.Empty;
    }

    public class UpdateCartaoDto
    {
        public string? Nome { get; set; }
        public decimal Valor { get; set; } = 0; 
        public string? Descricao { get; set; }
        public string? Status { get; set; }
    }
}