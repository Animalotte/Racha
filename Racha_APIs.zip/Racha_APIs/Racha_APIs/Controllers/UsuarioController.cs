﻿using Microsoft.AspNetCore.Mvc;
using Racha_APIs.data;
using Racha_APIs.models;
using System;
using System.Linq;

namespace Racha_APIs.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UsuarioController : ControllerBase
    {
        private readonly RachaDBContext _context;
        public UsuarioController(RachaDBContext context)
        {
            _context = context;
        }

        [HttpGet("por-codigo/{codigoUnico}")]
        public IActionResult GetUsuarioPorCodigo(string codigoUnico)
        {
            var usuario = _context.Usuarios.FirstOrDefault(u => u.CodigoUnico == codigoUnico);
            if (usuario == null)
            {
                return NotFound(new { message = "Usuário não encontrado" });
            }
            return Ok(usuario);
        }

        [HttpPost("criar")]
        public IActionResult CriarUsuario([FromBody] Usuario usuario)
        {
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).ToList();
                Console.WriteLine("Erros de validação: " + string.Join(", ", errors));
                return BadRequest(new { message = "Dados inválidos", errors });
            }

            var usuarioExistente = _context.Usuarios.FirstOrDefault(u => u.Cpf == usuario.Cpf || u.Email == usuario.Email);
            if (usuarioExistente != null)
            {
                Console.WriteLine("Usuário já existe com CPF ou Email");
                return Conflict(new { message = "Usuário já cadastrado com este CPF ou e-mail." });
            }

            try
            {
                _context.Usuarios.Add(usuario);
                _context.SaveChanges();
                Console.WriteLine("Usuário cadastrado com sucesso: " + usuario.Cpf);
                return Ok(new { message = "Usuário cadastrado com sucesso!", usuario });
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao salvar no banco: " + ex.Message);
                return StatusCode(500, new { message = "Erro ao cadastrar usuário.", detail = ex.Message });
            }
        }

        [HttpPost("login")]
        public IActionResult Login([FromBody] LoginRequest request)
        {
            if (string.IsNullOrEmpty(request.Cpf) || string.IsNullOrEmpty(request.Senha))
                return BadRequest(new { message = "CPF e senha são obrigatórios." });

            var usuario = _context.Usuarios.FirstOrDefault(u => u.Cpf == request.Cpf && u.Senha == request.Senha);
            if (usuario == null)
                return Unauthorized(new { message = "CPF ou senha incorretos." });

            return Ok(new
            {
                Id = usuario.Id,
                NomeCompleto = usuario.NomeCompleto,
                Email = usuario.Email,
                Cpf = usuario.Cpf,
                DataNascimento = usuario.DataNascimento,
                Cep = usuario.Cep,
                Endereco = usuario.Endereco,
                Cidade = usuario.Cidade,
                Estado = usuario.Estado,
                CodigoUnico = usuario.CodigoUnico,
                Creditos = usuario.Creditos,
                DataCadastro = usuario.DataCadastro
            });
        }

        [HttpGet]
        public IActionResult GetUsuarios()
        {
            return Ok(_context.Usuarios.ToList());
        }

        [HttpDelete("{id}")]
        public IActionResult DeletarUsuario(int id)
        {
            var usuario = _context.Usuarios.FirstOrDefault(u => u.Id == id);
            if (usuario == null)
                return NotFound(new { message = "Usuário não encontrado." });

            try
            {
                _context.Usuarios.Remove(usuario);
                _context.SaveChanges();
                return Ok(new { message = "Usuário excluído com sucesso!" });
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao deletar usuário: " + ex.Message);
                if (ex.InnerException != null && ex.InnerException.Message.Contains("foreign key"))
                {
                    return Conflict(new { message = "Não é possível deletar o usuário porque ele possui dependências (ex.: rachas ativas)." });
                }
                return StatusCode(500, new { message = "Erro interno ao deletar usuário.", detail = ex.Message });
            }
        }

        [HttpGet("{id}/creditos")]
        public IActionResult GetCreditos(int id)
        {
            var usuario = _context.Usuarios.Find(id);
            if (usuario == null)
            {
                return NotFound(new { message = "Usuário não encontrado" });
            }
            return Ok(new { creditos = usuario.Creditos });
        }

        [HttpPost("{id}/adicionar-creditos")]
        public IActionResult AdicionarCreditos(int id, [FromBody] AdicionarCreditosDto dto)
        {
            Console.WriteLine($"Recebido ID: {id}, Valor no DTO: {dto.Valor}, PaymentMethod: {dto.PaymentMethod}");
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var usuario = _context.Usuarios.Find(id);
            if (usuario == null)
            {
                return NotFound(new { message = "Usuário não encontrado" });
            }
            Console.WriteLine($"Créditos antes da adição: {usuario.Creditos}");
            try
            {
                usuario.Creditos += dto.Valor;
                Console.WriteLine($"Valor adicionado: {dto.Valor}, Créditos após: {usuario.Creditos}");
                _context.SaveChanges();

                var transacao = new Transacao
                {
                    UsuarioId = id,
                    Tipo = "credit_purchase",
                    Amount = dto.Valor,
                    FinalAmount = dto.Valor + (dto.Valor * 0.02m),
                    TaxAmount = dto.Valor * 0.02m,
                    PaymentMethod = dto.PaymentMethod,
                    Date = DateTime.UtcNow,
                    Description = $"Compra de R$ {dto.Valor} em créditos via {dto.PaymentMethod}"
                };
                _context.Transacoes.Add(transacao);
                _context.SaveChanges();

                return Ok(new { message = "Créditos adicionados com sucesso", creditosAtualizados = usuario.Creditos });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao adicionar créditos: {ex.Message}");
                return StatusCode(500, new { message = "Erro ao adicionar créditos", detail = ex.Message });
            }
        }

        [HttpGet("{id}")]
        public IActionResult GetUsuario(int id)
        {
            var usuario = _context.Usuarios.Find(id);
            if (usuario == null)
            {
                return NotFound(new { message = "Usuário não encontrado" });
            }
            return Ok(new
            {
                id = usuario.Id,
                nomeCompleto = usuario.NomeCompleto,
                email = usuario.Email,
                cpf = usuario.Cpf,
                dataNascimento = usuario.DataNascimento,
                cep = usuario.Cep,
                endereco = usuario.Endereco,
                cidade = usuario.Cidade,
                estado = usuario.Estado,
                codigoUnico = usuario.CodigoUnico,
                creditos = usuario.Creditos,
                dataCadastro = usuario.DataCadastro
            });
        }
    }


    public class LoginRequest
    {
        public string Cpf { get; set; } = string.Empty;
        public string Senha { get; set; } = string.Empty;
    }

    public class AdicionarCreditosDto
    {
        public decimal Valor { get; set; }
        public string PaymentMethod { get; set; } = "Pix";
    }
}