﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Racha_APIs.data;
using Racha_APIs.models;

namespace Racha_APIs.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TransacaoController : ControllerBase
    {
        private readonly RachaDBContext _context;

        public TransacaoController(RachaDBContext context)
        {
            _context = context;
        }

        [HttpGet("usuario/{usuarioId}")]
        public IActionResult GetTransacoesPorUsuario(int usuarioId)
        {
            var transacoes = _context.Transacoes
                .Where(t => t.UsuarioId == usuarioId)
                .OrderByDescending(t => t.Date)
                .ToList();

            return Ok(transacoes);
        }
    }
}