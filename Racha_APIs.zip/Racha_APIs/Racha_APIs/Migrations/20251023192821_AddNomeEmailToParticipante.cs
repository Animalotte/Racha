﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Racha_APIs.Migrations
{
    /// <inheritdoc />
    public partial class AddNomeEmailToParticipante : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Email",
                table: "Participantes",
                type: "TEXT",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Nome",
                table: "Participantes",
                type: "TEXT",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "CriadorNome",
                table: "Cartoes",
                type: "TEXT",
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateTable(
                name: "DadosCartaos",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    CartaoId = table.Column<int>(type: "INTEGER", nullable: false),
                    Numero = table.Column<string>(type: "TEXT", maxLength: 19, nullable: false),
                    Cvv = table.Column<string>(type: "TEXT", maxLength: 3, nullable: false),
                    Validade = table.Column<string>(type: "TEXT", maxLength: 5, nullable: false),
                    Nome = table.Column<string>(type: "TEXT", maxLength: 20, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DadosCartaos", x => x.Id);
                    table.ForeignKey(
                        name: "FK_DadosCartaos_Cartoes_CartaoId",
                        column: x => x.CartaoId,
                        principalTable: "Cartoes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_DadosCartaos_CartaoId",
                table: "DadosCartaos",
                column: "CartaoId",
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "DadosCartaos");

            migrationBuilder.DropColumn(
                name: "Email",
                table: "Participantes");

            migrationBuilder.DropColumn(
                name: "Nome",
                table: "Participantes");

            migrationBuilder.DropColumn(
                name: "CriadorNome",
                table: "Cartoes");
        }
    }
}
