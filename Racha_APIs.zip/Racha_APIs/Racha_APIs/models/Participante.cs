﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace Racha_APIs.models
{
    public class Participante
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int CartaoId { get; set; }

        [JsonIgnore]
        public Cartao? Cartao { get; set; }

        [Required]
        public int UsuarioId { get; set; }

        [JsonIgnore]
        public Usuario? Usuario { get; set; }

        [Required]
        public string Nome { get; set; } = string.Empty;

        [Required]
        [EmailAddress]
        public string Email { get; set; } = string.Empty;

        [Required]
        public string Status { get; set; } = "pendente";

        [Column(TypeName = "decimal(18,2)")]
        public decimal ValorPago { get; set; } = 0;

        public bool PagamentoRealizado { get; set; } = false;
    }
}