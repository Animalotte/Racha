﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Racha_APIs.models
{
    public class DadosCartao
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int CartaoId { get; set; }  // Chave estrangeira para Cartao

        public Cartao? Cartao { get; set; }  // Navegação de volta (opcional)

        [Required]
        [StringLength(19)]  // Formato: XXXX XXXX XXXX XXXX
        public string Numero { get; set; } = string.Empty;

        [Required]
        [StringLength(3)]
        public string Cvv { get; set; } = string.Empty;

        [Required]
        [StringLength(5)]  // Formato: MM/YY
        public string Validade { get; set; } = string.Empty;

        [Required]
        [StringLength(20)]
        public string Nome { get; set; } = string.Empty;

        // Construtor padrão (para EF Core)
        public DadosCartao() { }

        // Construtor para gerar dados automaticamente
        public DadosCartao(string nomeCartao)
        {
            Numero = GenerateCardNumber();
            Cvv = GenerateCvv();
            Validade = GenerateValidity();
            Nome = nomeCartao.ToUpper().Substring(0, Math.Min(20, nomeCartao.Length));
        }

        // Método auxiliar para gerar número de cartão válido (Mastercard-like, com Luhn)
        private string GenerateCardNumber()
        {
            string number = "5555";  // Prefixo Mastercard
            Random rand = new Random();
            for (int i = 0; i < 11; i++)
            {
                number += rand.Next(0, 10).ToString();
            }

            // Algoritmo Luhn para checksum
            int sum = 0;
            bool isEven = false;
            for (int i = number.Length - 1; i >= 0; i--)
            {
                int digit = int.Parse(number[i].ToString());
                if (isEven)
                {
                    digit *= 2;
                    if (digit > 9) digit -= 9;
                }
                sum += digit;
                isEven = !isEven;
            }
            int checksum = (10 - (sum % 10)) % 10;
            number += checksum.ToString();

            // Formatar com espaços
            return string.Join(" ", new[] { number.Substring(0, 4), number.Substring(4, 4), number.Substring(8, 4), number.Substring(12) });
        }

        // Método auxiliar para gerar CVV
        private string GenerateCvv()
        {
            Random rand = new Random();
            return rand.Next(100, 1000).ToString();
        }

        // Método auxiliar para gerar validade
        private string GenerateValidity()
        {
            Random rand = new Random();
            int month = rand.Next(1, 13);
            int year = DateTime.UtcNow.Year + rand.Next(3, 6);
            return $"{month:D2}/{year % 100:D2}";
        }
    }
}