﻿using System;

namespace Racha_APIs.models
{
    public class Transacao
    {
        public int Id { get; set; }
        public int UsuarioId { get; set; }
        public string Tipo { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public decimal? FinalAmount { get; set; }
        public decimal? TaxAmount { get; set; }
        public string? PaymentMethod { get; set; }
        public string Status { get; set; } = "completed";
        public DateTime Date { get; set; } = DateTime.UtcNow;
        public string Description { get; set; } = string.Empty;
        public int? CartaoId { get; set; }
        public string? CartaoName { get; set; }

        public Usuario Usuario { get; set; } = null!;
        public Cartao? Cartao { get; set; }
    }
}