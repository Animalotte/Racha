﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Racha_APIs.models
{
    public class Usuario
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string NomeCompleto { get; set; } = string.Empty;

        [Required, EmailAddress]
        public string Email { get; set; } = string.Empty;

        [Required]
        public string Cpf { get; set; } = string.Empty;

        [Required]
        public string DataNascimento { get; set; } = string.Empty;

        [Required]
        public string Cep { get; set; } = string.Empty;

        public string Endereco { get; set; } = string.Empty;
        public string Cidade { get; set; } = string.Empty;
        public string Estado { get; set; } = string.Empty;

        [Required]
        public string Senha { get; set; } = string.Empty;

        [Required]
        public string CodigoUnico { get; private set; }

        [Required]
        [Column(TypeName = "decimal(18,2)")]
        public decimal Creditos { get; set; } = 0;

        [Required]
        public DateTime DataCadastro { get; set; } = DateTime.UtcNow;

        // Construtor para inicializar CodigoUnico
        public Usuario()
        {
            CodigoUnico = GenerateUniqueCode();
        }

        private string GenerateUniqueCode()
        {
            var timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds().ToString("X");
            var random = Guid.NewGuid().ToString("N").Substring(0, 6).ToUpper();
            return $"{timestamp}{random}";
        }
    }
}