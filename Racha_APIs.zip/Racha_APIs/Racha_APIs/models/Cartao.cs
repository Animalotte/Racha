﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Racha_APIs.models
{
    public class Cartao
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Nome { get; set; } = string.Empty;

        [Required]
        [Column(TypeName = "decimal(18,2)")]
        public decimal Valor { get; set; }

        [Required]
        public int NumeroParticipantes { get; set; }

        [StringLength(500)]
        public string Descricao { get; set; } = string.Empty;

        [Required]
        public int CriadorId { get; set; }

        public Usuario? Criador { get; set; }  // Relação com usuário criador

        [Required]
        public string CriadorNome { get; set; } = string.Empty;  // Adicionado para compatibilidade com o controller

        [Required]
        public string Status { get; set; } = "pendente";  // pendente, ativo, validado

        [Required]
        public DateTime DataCriacao { get; set; } = DateTime.UtcNow;

        public List<Participante> Participantes { get; set; } = new List<Participante>();

        [Required]
        public string DivisaoTipo { get; set; } = "igualitaria";  // igualitaria, personalizada

        public int PagamentosRealizados { get; set; } = 0;

        // Nova propriedade: Dados do cartão (opcional, gerado apenas quando validado)
        public DadosCartao? DadosCartao { get; set; }
    }
}