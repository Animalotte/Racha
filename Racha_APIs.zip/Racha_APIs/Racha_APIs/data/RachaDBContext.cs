﻿using Microsoft.EntityFrameworkCore;
using Racha_APIs.models;

namespace Racha_APIs.data
{
    public class RachaDBContext : DbContext
    {
        public RachaDBContext(DbContextOptions<RachaDBContext> options) : base(options) { }

        // DbSets existentes
        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Cartao> Cartoes { get; set; }
        public DbSet<Participante> Participantes { get; set; }
        public DbSet<DadosCartao> DadosCartaos { get; set; }
        public DbSet<Transacao> Transacoes { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configurações existentes
            modelBuilder.Entity<Cartao>()
                .HasOne(c => c.Criador)
                .WithMany()
                .HasForeignKey(c => c.CriadorId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Participante>()
                .HasOne(p => p.Cartao)
                .WithMany(c => c.Participantes)
                .HasForeignKey(p => p.CartaoId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Participante>()
                .HasOne(p => p.Usuario)
                .WithMany()
                .HasForeignKey(p => p.UsuarioId)
                .OnDelete(DeleteBehavior.NoAction);

            // Nova configuração para DadosCartao (relação 1:1 opcional com Cartao)
            modelBuilder.Entity<DadosCartao>()
                .HasOne(d => d.Cartao)
                .WithOne(c => c.DadosCartao)
                .HasForeignKey<DadosCartao>(d => d.CartaoId)
                .OnDelete(DeleteBehavior.Cascade);  // Se Cartao for deletado, DadosCartao também será

            base.OnModelCreating(modelBuilder);
        }
    }
}